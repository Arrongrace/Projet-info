-- Script SQL pour insérer les données dans la base de données 'Pokemon'

-- Insérer des types de Pokémon
INSERT INTO Pokedex.Type (id_type, nom_type) VALUES
(1, 'Feu'),
(2, 'Eau'),
(3, 'Plante'),
(4, 'Électrique'),
(5, 'Normal'),
(6, 'Dragon'),
(7, 'Insecte'),
(8, 'Roche'),
(9, 'Sol'),
(10, 'Poison'),
(11, 'Psy'),
(12, 'Vol'),
(13, 'Combat'),
(14, 'Glace'),
(15, 'Spectre');

-- Insérer des Pokémon
INSERT INTO Pokedex.Pokemon (id_pokemon, nom, pokedex_number, attaque_base, attaquespe_base,   defense_base, defensespe_base, vitesse_base, pv_base)
VALUES
	(1, 'Bulbizarre', 45, 49, 49, 65, 65, 45, 40),
	(2, 'Herbizarre', 60, 62, 63, 80, 80, 60, 60),
	(3, 'Florizarre', 80, 82, 83, 100, 100, 80, 60),
	(4, 'Salamèche', 39, 52, 43, 60, 50, 65, 39),
	(5, 'Reptincel', 58, 64, 58, 80, 65, 80, 58),
	(6, 'Dracaufeu', 78, 84, 78, 109, 85, 100, 78),
	(7, 'Carapuce', 44, 48, 65, 50, 64, 43, 44),
	(8, 'Carabaffe', 59, 63, 80, 65, 80, 58, 59),
	(9, 'Tortank', 79, 83, 100, 85, 105, 78, 79),
	(10, 'Chenipan', 45, 30, 35, 20, 20, 45, 45),
	(11, 'Chrysacier', 50, 20, 55, 25, 25, 45, 50),
	(12, 'Papilusion', 60, 45, 50, 90, 80, 70, 60),
	(13, 'Aspicot', 40, 35, 30, 20, 20, 50, 40),
	(14, 'Coconfort', 50, 25, 35, 25, 25, 45, 50),
	(15, 'Dardargnan', 65, 90, 40, 45, 80, 75, 65),
	(16, 'Roucool', 40, 45, 40, 35, 35, 56, 40),
	(17, 'Roucoups', 60, 60, 55, 50, 50, 71, 60),
	(18, 'Roucarnage', 80, 85, 70, 65, 75, 101, 80),
	(19, 'Rattata', 30, 56, 35, 25, 35, 56, 30),
	(20, 'Rattatac', 55, 81, 60, 30, 40, 97, 55),
	(21, 'Piafabec', 40, 45, 35, 30, 30, 56, 40),
	(22, 'Rapasdepic', 60, 60, 55, 50, 50, 71, 60),
	(23, 'Abo', 40, 60, 44, 40, 54, 55, 40),
	(24, 'Arbok', 60, 85, 69, 65, 79, 80, 60),
	(25, 'Pikachu', 35, 55, 40, 50, 50, 90, 35),
	(26, 'Raichu', 60, 90, 55, 50, 80, 100, 60),
	(27, 'Sabelette', 50, 45, 45, 20, 30, 50, 50),
	(28, 'Sablaireau', 75, 100, 70, 40, 50, 70, 75),
	(29, 'Nidoran femelle', 55, 47, 52, 40, 40, 41, 55),
	(30, 'Nidorina', 70, 62, 67, 55, 55, 56, 70),
	(31, 'Nidoqueen', 90, 92, 87, 75, 85, 76, 90),
	(32, 'Nidoran mâle', 46, 57, 40, 40, 40, 50, 46),
	(33, 'Nidorino', 61, 72, 57, 55, 55, 65, 61),
	(34, 'Nidoking', 81, 102, 77, 75, 85, 85, 81),
	(35, 'Mélofée', 70, 45, 48, 60, 65, 35, 70),
	(36, 'Mélodelfe', 95, 70, 73, 85, 90, 55, 95),
	(37, 'Goupix', 38, 41, 40, 50, 65, 65, 38),
	(38, 'Feunard', 73, 76, 75, 81, 100, 100, 73),
	(39, 'Rondoudou', 115, 45, 50, 25, 45, 20, 115),
	(40, 'Grodoudou', 140, 70, 85, 50, 55, 45, 140),
	(41, 'Nosferapti', 40, 30, 35, 40, 55, 75, 40),
	(42, 'Nosferalto', 60, 45, 50, 55, 70, 95, 60),
	(43, 'Mystherbe', 60, 40, 35, 50, 50, 30, 60),
	(44, 'Ortide', 75, 65, 55, 60, 60, 40, 75),
	(45, 'Rafflesia', 85, 70, 65, 90, 85, 50, 85),
	(46, 'Paras', 35, 70, 55, 35, 55, 25, 35),
	(47, 'Parasect', 60, 95, 80, 60, 80, 30, 60),
	(48, 'Mimitoss', 40, 35, 30, 20, 20, 50, 40),
	(49, 'Aéromite', 50, 25, 35, 25, 25, 45, 50),
	(50, 'Taupiqueur', 55, 35, 45, 20, 30, 50, 55),
	(51, 'Triopikeur', 85, 60, 70, 40, 50, 75, 85),
	(52, 'Miaouss', 40, 45, 35, 35, 35, 56, 40),
	(53, 'Persian', 65, 70, 60, 50, 65, 115, 65),
	(54, 'Psykokwak', 50, 52, 48, 35, 50, 55, 50),
	(55, 'Akwakwak', 80, 72, 68, 65, 80, 70, 80),
	(56, 'Férosinge', 50, 105, 35, 35, 35, 55, 50),
	(57, 'Colossinge', 85, 140, 70, 70, 70, 60, 85),
	(58, 'Caninos', 39, 60, 45, 50, 50, 65, 39),
	(59, 'Arcanin', 90, 110, 80, 80, 95, 95, 90),
	(60, 'Ptitard', 40, 50, 40, 50, 50, 60, 40),
	(61, 'Têtarte', 50, 65, 50, 60, 60, 70, 50),
	(62, 'Tartard', 60, 85, 70, 75, 75, 95, 60),
	(63, 'Abra', 25, 20, 15, 105, 55, 90, 25),
	(64, 'Kadabra', 40, 35, 35, 135, 95, 105, 40),
	(65, 'Alakazam', 55, 50, 45, 150, 105, 120, 55),
	(66, 'Machoc', 70, 80, 50, 35, 35, 35, 70),
	(67, 'Machopeur', 80, 100, 60, 50, 60, 55, 80),
	(68, 'Mackogneur', 90, 130, 75, 65, 85, 55, 90),
	(69, 'Chétiflor', 40, 50, 35, 55, 55, 30, 40),
	(70, 'Boustiflor', 60, 75, 60, 75, 70, 40, 60),
	(71, 'Empiflor', 75, 90, 70, 100, 90, 50, 75),
	(72, 'Tentacool', 40, 40, 35, 50, 100, 70, 40),
	(73, 'Tentacruel', 80, 70, 60, 80, 120, 100, 80),
	(74, 'Racaillou', 40, 80, 30, 35, 30, 20, 40),
	(75, 'Gravalanch', 55, 95, 45, 50, 45, 35, 55),
	(76, 'Grolem', 80, 110, 80, 50, 50, 40, 80),
	(77, 'Ponyta', 50, 65, 40, 50, 50, 90, 50),
	(78, 'Galopa', 65, 80, 50, 65, 65, 105, 65),
	(79, 'Ramoloss', 65, 40, 50, 50, 40, 30, 65),
	(80, 'Flagadoss', 95, 65, 80, 80, 70, 60, 95),
	(81, 'Magnéti', 25, 35, 70, 95, 55, 45, 25),
	(82, 'Magnéton', 50, 60, 95, 120, 70, 70, 50),
	(83, 'Canarticho', 60, 60, 55, 50, 50, 71, 60),
	(84, 'Doduo', 35, 85, 45, 35, 35, 75, 35),
	(85, 'Dodrio', 60, 110, 70, 60, 60, 100, 60),
	(86, 'Otaria', 35, 70, 30, 95, 70, 55, 35),
	(87, 'Lamantine', 85, 70, 80, 95, 80, 70, 85),
	(88, 'Tadmorv', 60, 60, 50, 40, 50, 50, 60),
	(89, 'Grotadmorv', 95, 105, 75, 65, 100, 75, 95),
	(90, 'Kokiyas', 30, 65, 95, 25, 45, 85, 30),
	(91, 'Crustabri', 50, 95, 130, 55, 85, 65, 50),
	(92, 'Fantominus', 30, 35, 30, 100, 35, 80, 30),
	(93, 'Spectrum', 50, 50, 45, 115, 55, 95, 50),
	(94, 'Ectoplasma', 60, 65, 60, 130, 75, 110, 60),
	(95, 'Onix', 35, 45, 160, 30, 45, 70, 35),
	(96, 'Soporifik', 60, 48, 45, 65, 40, 42, 60),
	(97, 'Hypnomade', 85, 73, 70, 95, 60, 67, 85),
	(98, 'Krabby', 30, 105, 90, 25, 25, 50, 30),
	(99, 'Krabboss', 55, 130, 115, 50, 50, 75, 55),
	(100, 'Voltorbe', 40, 30, 35, 50, 55, 100, 40),
	(101, 'Electrode', 60, 50, 45, 70, 80, 150, 60),
	(102, 'Noeunoeuf', 40, 50, 35, 75, 85, 40, 40),
	(103, 'Noadkoko', 60, 75, 60, 85, 100, 60, 60),
	(104, 'Osselait', 30, 45, 45, 30, 40, 60, 30),
	(105, 'Ossatueur', 60, 80, 110, 45, 55, 70, 60),
	(106, 'Kicklee', 50, 120, 53, 35, 35, 105, 50),
	(107, 'Tygnon', 60, 105, 60, 35, 35, 115, 60),
	(108, 'Excelangue', 95, 85, 60, 55, 60, 50, 95),
	(109, 'Smogo', 65, 90, 40, 45, 55, 35, 65),
	(110, 'Smogogo', 95, 100, 60, 65, 100, 60, 95),
	(111, 'Rhinocorne', 80, 85, 95, 30, 30, 25, 80),
	(112, 'Rhinoféros', 105, 130, 120, 45, 45, 40, 105),
	(113, 'Leveinard', 250, 5, 5, 35, 105, 50, 250),
	(114, 'Saquedeneu', 60, 75, 60, 90, 75, 40, 60),
	(115, 'Kangourex', 105, 95, 80, 40, 70, 90, 105),
	(116, 'Hypotrempe', 35, 65, 55, 45, 50, 70, 35),
	(117, 'Hypocéan', 65, 95, 75, 70, 70, 95, 65),
	(118, 'Poissirène', 50, 48, 45, 50, 45, 45, 50),
	(119, 'Poissoroy', 65, 70, 70, 60, 60, 75, 65),
	(120, 'Stari', 30, 45, 50, 70, 55, 85, 30),
	(121, 'Staross', 60, 75, 85, 95, 85, 115, 60),
	(122, 'M. Mime', 40, 45, 65, 100, 120, 90, 40),
	(123, 'Insécateur', 70, 110, 80, 55, 80, 105, 70),
	(124, 'Lippoutou', 65, 50, 55, 110, 95, 60, 65),
	(125, 'Elektek', 65, 95, 57, 100, 85, 95, 65),
	(126, 'Magmar', 65, 95, 57, 85, 95, 93, 65),
	(127, 'Scarabrute', 80, 100, 70, 55, 80, 65, 80),
	(128, 'Tauros', 75, 100, 95, 40, 70, 110, 75),
	(129, 'Magicarpe', 20, 10, 55, 15, 20, 80, 20),
	(130, 'Léviator', 95, 125, 79, 60, 100, 81, 95),
	(131, 'Lokhlass', 130, 85, 80, 95, 95, 60, 130),
	(132, 'Métamorph', 48, 48, 48, 48, 48, 48, 48),
	(133, 'Evoli', 55, 55, 50, 40, 50, 55, 55),
	(134, 'Aquali', 65, 60, 65, 50, 95, 65, 65),
	(135, 'Voltali', 65, 65, 60, 110, 95, 75, 65),
	(136, 'Pyroli', 65, 130, 60, 95, 65, 65, 65),
	(137, 'Porygon', 65, 60, 70, 40, 75, 40, 65),
	(138, 'Amonita', 35, 40, 100, 30, 35, 70, 35),
	(139, 'Amonistar', 70, 60, 125, 40, 55, 80, 70),
	(140, 'Kabuto', 30, 40, 50, 30, 45, 55, 30),
	(141, 'Kabutops', 60, 115, 105, 65, 70, 80, 60),
	(142, 'Ptéra', 60, 70, 65, 40, 60, 130, 60),
	(143, 'Ronflex', 160, 110, 65, 65, 110, 30, 160),
	(144, 'Artikodin', 90, 85, 100, 95, 125, 85, 90),
	(145, 'Electhor', 90, 90, 85, 125, 90, 100, 90),
	(146, 'Sulfura', 90, 100, 90, 85, 90, 125, 90),
	(147, 'Minidraco', 41, 45, 40, 35, 35, 56, 41),
	(148, 'Draco', 61, 80, 60, 50, 50, 65, 61),
	(149, 'Dracolosse', 91, 134, 95, 85, 85, 110, 91),
	(150, 'Mewtwo', 106, 110, 90, 154, 90, 130, 106),
	(151, 'Mew', 100, 100, 100, 100, 100, 100, 100);



-- Associer les types aux Pokémon
INSERT INTO Pokedex.A_pour_Type (id_pokemon, id_type1,id_type2) VALUES
	(1,3, 10),  -- Bulbizarre : type Plante Poison
	(2,3, 10),  -- Herbizarre : type Plante Poison
	(3,3, 10),  -- Florizarre : type Plante Poison
	(4, 1),   -- Salamèche : type Feu
	(5, 1),   -- Reptincel : type Feu
	(6, 1, 12),  -- Dracaufeu : type Feu Vol
	(7, 2),   -- Carapuce : type Eau
	(8, 2),   -- Carabaffe : type Eau
	(9, 2),   -- Tortank : type Eau
	(10, 7),  -- Chenipan : type Insecte
	(11, 7),  -- Chrysacier : type Insecte
	(12, 7, 12),  -- Papilusion : type Insecte Vol
	(13, 7, 10),  -- Aspicot : type Insecte Poison
	(14, 7, 10),  -- Coconfort : type Insecte Poison
	(15, 7, 10),  -- Dardargnan : type Insecte Poison
	(16, 5, 12),  -- Roucool : type Normal Vol
	(17, 5, 12),  -- Roucoups : type Normal Vol
	(18, 5, 12),  -- Roucarnage : type Normal Vol
	(19, 5),   -- Rattata : type Normal
	(20, 5),   -- Rattatac : type Normal
	(21, 5, 12),  -- Piafabec : type Normal Vol
	(22, 5, 12),  -- Rapasdepic : type Normal Vol
	(23, 10),  -- Abo : type Poison
	(24, 10),  -- Arbok : type Poison
	(25, 4),   -- Pikachu : type Électrique
	(26, 4),   -- Raichu : type Électrique
	(27, 9),   -- Sabelette : type Sol
	(28, 9),   -- Sablaireau : type Sol
	(29, 10),  -- Nidoran femelle : type Poison
	(30, 10),  -- Nidorina : type Poison
	(31, 9, 10),  -- Nidoqueen : type Poison
	(32, 10),  -- Nidoran mâle : type Poison Sol
	(33, 10),  -- Nidorino : type Poison
	(34, 9, 10),  -- Nidoking : type Poison Sol
	(35, 5),   -- Mélofée : type Normal
	(36, 5),   -- Mélodelfe : type Normal
	(37, 1),   -- Goupix : type Feu
	(38, 1),   -- Feunard : type Feu
	(39, 5),   -- Rondoudou : type Normal
	(40, 5),   -- Grodoudou : type Normal
	(41, 12, 10),  -- Nosferapti : type Vol Poison
	(42, 12, 10),  -- Nosferalto : type Vol Poison
	(43, 3, 10),   -- Mystherbe : type Plante Poison
	(44, 3, 10),   -- Ortide : type Plante Poison
	(45, 3, 10),   -- Rafflesia : type Plante Poison
	(46, 7, 3),	-- Paras : type Insecte Plante
	(47, 7, 3),	-- Parasect : type Insecte Plante
	(48, 7, 10),   -- Mimitoss : type Insecte Poison
	(49, 7, 10),   -- Aéromite : type Insecte Poison
	(50, 9),   -- Taupiqueur : type Sol
	(51, 9),   -- Triopikeur : type Sol
	(52, 5),   -- Miaouss : type Normal
	(53, 5),   -- Persian : type Normal
	(54, 2),   -- Psykokwak : type Eau
	(55, 2),   -- Akwakwak : type Eau
	(56, 13),  -- Férosinge : type Combat
	(57, 13),  -- Colossinge : type Combat
	(58, 1),   -- Caninos : type Feu
	(59, 1),   -- Arcanin : type Feu
	(60, 2),   -- Ptitard : type Eau
	(61, 2),   -- Têtarte : type Eau
	(62, 2, 13),   -- Tartard : type Eau Combat
	(63, 11),  -- Abra : type Psy
	(64, 11),  -- Kadabra : type Psy
	(65, 11),  -- Alakazam : type Psy
	(66, 13),  -- Machoc : type Combat
	(67, 13),  -- Machopeur : type Combat
	(68, 13),  -- Mackogneur : Combat
	(69, 3),   -- Chétiflor : type Plante
	(70, 3, 10),   -- Boustiflor : type Plante Poison
	(71, 3, 10),   -- Empiflor : type Plante Poison
	(72, 2, 10),  -- Tentacool : type Eau Poison
	(73, 2, 10),  -- Tentacruel : type Eau Poison
	(74, 9, 8),   -- Racaillou : type Sol Roche
	(75, 9, 8),   -- Gravalanch : type Sol Roche
	(76, 9, 8),   -- Grolem : Sol Roche
	(77, 1),   -- Ponyta : Feu
	(78, 1),   -- Galopa : type Feu
	(79, 2, 11),  -- Ramoloss : type Eau Psy
	(80, 2, 11),  -- Flagadoss : type Eau Psy
	(81, 4),   -- Magnéti : type Electrique 
	(82, 4),   -- Magnéton : type Électrique 
	(83, 5, 12),  -- Canarticho : type Normal Vol
	(84, 5, 12),  -- Doduo : type Normal Vol
	(85, 5, 12),  -- Dodrio : type Normal Vol
	(86, 2),   -- Otaria : Eau
	(87, 2, 14),   -- Lamantine : type Eau Glace
	(88, 10),  -- Tadmorv : type Poison
	(89, 10),  -- Grotadmorv : type Poison
	(90, 2),   -- Kokiyas : type Eau
	(91, 2, 14),  -- Crustabri : type Eau Glace
	(92, 15, 10),  -- Fantominus : type Spectre Poison
	(93, 15, 10),  -- Spectrum : type Spectre Poison
	(94, 15, 10),  -- Ectoplasma : type Spectre Poison
	(95, 9, 8),   -- Onix : type Sol Roche
	(96, 11),  -- Soporifik : type Psy
	(97, 11),  -- Hypnomade : type Psy
	(98, 2),   -- Krabby : type Eau
	(99, 2),   -- Krabboss : type Eau
	(100, 4),  -- Voltorbe : type Electrique
	(101, 4),  -- Electrode : type Electrique
	(102, 3, 11),  -- Noeunoeuf : type Plante Psy
	(103, 3, 11),  -- Noadkoko : type Plante Psy
	(104, 9),   -- Osselait : type Sol
	(105, 9),   -- Ossatueur : type Sol
	(106, 13),  -- Kicklee : type Combat
	(107, 13),  -- Tygnon : type Combat
	(108, 5),   -- Excelangue : type Normal
	(109, 10),  -- Smogo : type Poison
	(110, 10),  -- Smogogo : type Poison
	(111, 9, 8),   -- Rhinocorne : type Sol Roche
	(112, 9, 8),   -- Rhinoféros : Sol Roche
	(113, 5),   -- Leveinard : Normal
	(114, 3),   -- Saquedeneu : Plante
	(115, 5),   -- Kangourex : type Normal
	(116, 2),   -- Hypotrempe : type Eau
	(117, 2),   -- Hypocéan : type Eau
	(118, 2),   -- Poissirène : type Eau
	(119, 2),   -- Poissoroy : type Eau
	(120, 2),   -- Stari : type Eau
	(121, 2, 11),  -- Staross : type Eau Psy
	(122, 11),  -- M. Mime : type Psy
	(123, 7),   -- Insécateur : type Insecte
	(124, 14, 11),  -- Lippoutou : type Glace Psy
	(125, 4),   -- Elektek : type Electrique
	(126, 1),   -- Magmar : type Feu
	(127, 7),   -- Scarabrute : type Insecte
	(128, 5),   -- Tauros : type Normal
	(129, 2),   -- Magicarpe : type Eau
	(130, 2, 12),  -- Léviator : type Eau Vol
	(131, 2, 14),  -- Lokhlass : type Eau Glace
	(132, 5),   -- Métamorph : type Normal
	(133, 5),   -- Evoli : type Normal
	(134, 2),   -- Aquali : type Eau
	(135, 4),   -- Voltali : type Electrique
	(136, 1),   -- Pyroli : type Feu
	(137, 5),   -- Porygon : type Normal
	(138, 8, 2),   -- Amonita : type Roche Eau
	(139, 8, 2),   -- Amonistar : type Roche Eau
	(140, 8, 2),   -- Kabuto : type Roche Eau
	(141, 8, 2),   -- Kabutops : type Roche Eau
	(142, 8, 12),  -- Ptéra : type Roche Vol
	(143, 5),   -- Ronflex : type Normal
	(144, 14, 12),  -- Artikodin : type Glace Vol
	(145, 4, 12),   -- Electhor : type Electrique Vol
	(146, 1, 12),   -- Sulfura : type Feu Vol
	(147, 6),   -- Minidraco : type Dragon
	(148, 6),   -- Draco : type Dragon
	(149, 6, 12),  -- Dracolosse : type Dragon Vol
	(150, 11),  -- Mewtwo : type Psy
	(151, 11);   -- Mew : type Psy




-- Insérer des attaques
INSERT INTO Pokedex.Attaque (id_attaque, nom_attaque, type_attaque) VALUES
	(1, 'Abîme','Sol'),
	(2, 'Acidarmure', 'Poison'),
	(3, 'Acide', 'Poison'),
	(4, 'Adaptation', 'Normal'),
	(5, 'Affûtage', 'Normal'),
	(6, 'Amnésie', 'Psy'),
	(7, 'Armure', 'Normal'),
	(8, 'Balayage', 'Combat'),
	(9, 'Bec Vrille', 'Vol'),
	(10, 'Bélier', 'Normal'),
	(11, 'Berceuse', 'Normal'),
	(12, 'Blizzard', 'Glace'),
	(13, 'BombŒuf','Normal'),
	(14, 'Bouclier', 'Psy'),
	(15, 'BoulArmure', 'Normal'),
	(16, 'Brouillard', 'Normal'),
	(17, 'Brume', 'Glace'),
	(18, 'Buée Noire', 'Glace'),
	(19, 'Bulles dO', 'Eau'),
	(20, 'Cage-Éclair', 'Électrik'),
	(21, 'Cascade', 'Eau'),
	(22, 'Charge', 'Normal'),
	(23, 'Choc Mental', 'Psy'),
	(24, 'Claquoir', 'Eau'),
	(25, 'Clonage', 'Normal'),
	(26, 'Combo-Griffe', 'Normal'),
	(27, 'Constriction', 'Normal'),
	(28, 'Copie', 'Normal'),
	(29, 'CoudKrâne', 'Normal'),
	(30, 'Coup dBoule', 'Normal'),
	(31, 'Coupe', 'Normal'),
	(32, 'Coupe-Vent', 'Normal'),
	(33, 'Croc de Mort', 'Normal'),
	(34, 'Croc Fatal', 'Normal'),
	(35, 'Croissance', 'Normal'),
	(36, 'Cru-Aile', 'Vol'),
	(37, 'Cyclone', 'Normal'),
	(38, 'Damoclès', 'Normal'),
	(39, 'Danse-Fleur', 'Plante'),
	(40, 'Danse-Lames', 'Normal'),
	(41, 'Danseflamme', 'Feu'),
	(42, 'Dard-Nuée', 'Insecte'),
	(43, 'Dard-Venin', 'Poison'),
	(44, 'Déflagration', 'Feu'),
	(45, 'Destruction', 'Normal'),
	(46, 'Détritus', 'Poison'),
	(47, 'Dévorêve', 'Psy'),
	(48, 'Double Pied', 'Combat'),
	(49, 'Double-Dard', 'Insecte'),
	(50, 'Draco-Rage', 'Dragon'),
	(51, 'E-Coque', 'Normal'),
	(52, 'Éboulement', 'Roche'),
	(53, 'Éclair', 'Électrik'),
	(54, 'ÉcrasFace', 'Normal'),
	(55, 'Écrasement', 'Normal'),
	(56, 'Écume', 'Eau'),
	(57, 'EmpalKorne', 'Normal'),
	(58, 'Entrave', 'Normal'),
	(59, 'Étreinte', 'Normal'),
	(60, 'Explosion', 'Normal'),
	(61, 'Fatal-Foudre', 'Électrik'),
	(62, 'Flammèche', 'Feu'),
	(63, 'Flash', 'Normal'),
	(64, 'Force', 'Normal'),
	(65, 'Force Poigne', 'Normal'),
	(66, 'Fouet Lianes', 'Plante'),
	(67, 'Frappe Atlas', 'Combat'),
	(68, 'Frénésie', 'Normal'),
	(69, 'Furie', 'Normal'),
	(70, 'Gaz Toxik', 'Poison'),
	(71, 'Griffe', 'Normal'),
	(72, 'Grincement', 'Normal'),
	(73, 'Grobisou', 'Normal'),
	(74, 'GrozYeux', 'Normal'),
	(75, 'Guillotine', 'Normal'),
	(76, 'Hâte', 'Psy'),
	(77, 'Hurlement', 'Normal'),
	(78, 'Hydrocanon', 'Eau'),
	(79, 'Hypnose', 'Psy'),
	(80, 'Intimidation', 'Normal'),
	(81, 'Jackpot', 'Normal'),
	(82, 'Jet de Sable', 'Normal'),
	(83, 'Jet-Pierres', 'Roche'),
	(84, 'KoudKorne', 'Normal'),
	(85, 'Lance-Flamme', 'Feu'),
	(86, 'Lance-Soleil', 'Plante'),
	(87, 'Laser Glace', 'Glace'),
	(88, 'Léchouille', 'Spectre'),
	(89, 'Ligotage', 'Normal'),
	(90, 'Lilliput', 'Normal'),
	(91, 'Lutte', 'Normal'),
	(92, 'Mania', 'Normal'),
	(93, 'MassdOs', 'Sol'),
	(94, 'Mawashi Geri', 'Combat'),
	(95, 'Méga-Sangsue', 'Plante'),
	(96, 'Météores', 'Normal'),
	(97, 'Métronome', 'Normal'),
	(98, 'Mimi-Queue', 'Normal'),
	(99, 'Mimique', 'Vol'),
	(100, 'Morphing', 'Normal'),
	(101, 'Morsure', 'Normal'),
	(102, 'Mur Lumière', 'Psy'),
	(103, 'Onde Boréale', 'Glace'),
	(104, 'Onde Folie', 'Spectre'),
	(105, 'Osmerang', 'Sol'),
	(106, 'Para-Spore', 'Plante'),
	(107, 'Patience', 'Normal'),
	(108, 'Picanon', 'Normal'),
	(109, 'Picpic', 'Vol'),
	(110, 'Pied Sauté', 'Combat'),
	(111, 'Pied Voltige', 'Combat'),
	(112, 'Pilonnage', 'Normal'),
	(113, 'Pince-Masse', 'Eau'),
	(114, 'Pique', 'Vol'),
	(115, 'Pistolet à O', 'Eau'),
	(116, 'Plaquage', 'Normal'),
	(117, 'Poing Comète', 'Normal'),
	(118, 'Poing de Feu', 'Feu'),
	(119, 'Poing-Éclair', 'Électrik'),
	(120, 'Poing-Karaté', 'Normal'),
	(121, 'Poinglace', 'Glace'),
	(122, 'Poudre Dodo', 'Plante'),
	(123, 'Poudre Toxik', 'Poison'),
	(124, 'Protection', 'Psy'),
	(125, 'Psyko', 'Psy'),
	(126, 'Puissance', 'Normal'),
	(127, 'Purédpois', 'Normal'),
	(128, 'Rafale Psy', 'Psy'),
	(129, 'Reflet', 'Normal'),
	(130, 'Repli', 'Eau'),
	(131, 'Repos', 'Psy'),
	(132, 'Riposte', 'Combat'),
	(133, 'Rugissement', 'Normal'),
	(134, 'Sacrifice', 'Combat'),
	(135, 'Sécrétion', 'Insecte'),
	(136, 'Séisme', 'Sol'),
	(137, 'Soin', 'Normal'),
	(138, 'Sonicboom', 'Normal'),
	(139, 'Souplesse', 'Normal'),
	(140, 'Spore', 'Plante'),
	(141, 'Surf', 'Eau'),
	(142, 'Télékinésie', 'Psy'),
	(143, 'Téléport', 'Psy'),
	(144, 'Ténèbres', 'Spectre'),
	(145, 'Tonnerre', 'Électrik'),
	(146, 'Torgnoles', 'Normal'),
	(147, 'Tornade', 'Normal'),
	(148, 'Toxik', 'Poison'),
	(149, 'TranchHerbe', 'Plante'),
	(150, 'Tranche', 'Normal'),
	(151, 'Trempette', 'Normal'),
	(152, 'Triplattaque', 'Normal'),
	(153, 'Tunnel', 'Sol'),
	(154, 'Ultimapoing', 'Normal'),
	(155, 'Ultimawashi', 'Normal'),
	(156, 'Ultralaser', 'Normal'),
	(157, 'Ultrason', 'Normal'),
	(158, 'Uppercut', 'Normal'),
	(159, 'Vague Psy', 'Psy'),
	(160, 'Vampigraine', 'Plante'),
	(161, 'Vampirisme', 'Insecte'),
	(162, 'Vive-Attaque', 'Normal'),
	(163, 'Vol', 'Vol'),
	(164, 'Vol-Vie', 'Plante'),
	(165, 'Yoga', 'Psy');




-- Associer les attaques aux Pokémon
INSERT INTO Pokedex.Peut_apprendre (id_pokemon, id_attaque) VALUES
(1, 22),    
(1, 39),    
(2, 16),    
(2, 61),    
(3, 118),   
(3, 86),    
(4, 12),    
(4, 61),    
(5, 16),    
(5, 38),    
(6, 163),   
(6, 85),    
(7, 50),    
(7, 21),    
(8, 30),    
(8, 21),    
(9, 116),   
(9, 56),    
(10, 135),  
(10, 22),   
(11, 7),    
(11, 135),  
(12, 164),  
(12, 123),  
(13, 43),   
(13, 135),  
(14, 7),    
(14, 135),  
(15, 42),   
(15, 49),   
(16, 147),  
(16, 98),   
(17, 109),  
(17, 82),   
(18, 163),  
(18, 114),  
(19, 133),  
(19, 22),   
(20, 33),   
(20, 34),   
(21, 109),  
(21, 83),   
(22, 114),  
(22, 163),  
(23, 59),   
(23, 89),   
(24, 89),   
(24, 101),  
(25, 20),   
(25, 53),   
(26, 145),  
(26, 20),   
(27, 153),  
(27, 26),   
(28, 136),  
(28, 139),  
(29, 71),   
(29, 133),  
(30, 48),   
(30, 43),   
(31, 136),  
(31, 57),   
(32, 71),   
(32, 133),  
(33, 48),   
(33, 43),   
(34, 57),   
(34, 136),  
(35, 137),  
(35, 97),   
(36, 137),  
(36, 73),   
(37, 137),  
(37, 96),   
(38, 62),   
(38, 133),  
(39, 85),   
(39, 41),   
(40, 73),   
(40, 11),   
(41, 11),   
(41, 28),   
(42, 36),   
(42, 104),  
(43, 58),   
(43, 43),   
(44, 163),  
(44, 161),  
(45, 164),  
(45, 122),  
(46, 3),    
(46, 123),  
(47, 46),   
(47, 95),   
(48, 106),  
(48, 42),   
(49, 106),  
(49, 66),   
(50, 153),  
(50, 136),  
(51, 153),  
(51, 136),  
(52, 81),   
(52, 101),  
(53, 101),  
(53, 34),   
(54, 115),  
(54, 142),  
(55, 130),  
(55, 78),   
(56, 67),   
(56, 120),  
(57, 94),   
(57, 110),  
(58, 62),   
(58, 77),   
(59, 44),   
(59, 150),  
(60, 130),  
(60, 115),  
(61, 115),  
(61, 139),  
(62, 120),  
(62, 141),  
(63, 143),  
(63, 142),  
(64, 128),  
(64, 79),   
(65, 125),  
(65, 102),  
(66, 126),  
(66, 132),  
(67, 134),  
(67, 111),  
(68, 111),  
(68, 120),  
(69, 160),  
(69, 66),   
(70, 3),    
(70, 2),    
(71, 46),   
(71, 86),   
(72, 43),   
(72, 56),   
(73, 141),  
(73, 90),   
(74, 153),  
(74, 83),   
(75, 52),   
(75, 64);    
(75,83)
(75,45)
(76,136)
(76,60)
(77,62)
(77,41)
(78,76)
(78,55)
(79,23)
(79,58)
(80,125)
(80,130)
(81,53)
(81,22)
(82,53)
(82,22)
(83,109)
(83,69)
(84,109)
(84,9)
(85,109)
(85,9)
(86,103)
(86,30)
(87,103
(87,30)
(88,70)
(88,46)
(89,2)
(89,46)
(90,87)
(90,130)
(91,108)
(91,103)
(92,47)
(92,79)
(93,47)
(93,79)
(94,47)
(94,79)
(95,83)
(95,139)
(96,165)
(96,125)
(97,125)
(97,165)
(98,113)
(98,75)
(99,65)
(99,113)
(100,45)
(100,60)
(101,45)
(101,60)
(102,112)
(102,124)
(103,112)
103,114)
(104,105)
(104,93)
(105,105)
(105,93)
(106,111)
(106,132)
(107,117)
(107,121)
(108,139)
(108,15)
(109,127)
(109,60)
(110,127)
(110,60)
(111,84)
(111,55)
(112,84)
(112,55)
(113,90) 
(113,38)
(114,164)
(114,123)
(115,101)
(115,98)
(116, 78)
(116, 74)
(117,16)
(117,115)
(118,151)
(118,141)
(119,141)
(119,57)
(120,115)
(120,125)
(121,115)
(121,125)
(122,125)
(122,124)
(123,150)
(123,162)
(124,125)
(124,159)
(125,154)
(125,119)
(126,118)
(126,127)
(127,134)
(127,30)
(128,68)
(128,84)
(129,22)
(129,151)
(130,78)
(130,50)
(131,87)
(131,103)
(132,100)
(132,22)
(133,22)
(133,74)
(134,78)
(134,141)
(135145,)
(135,108)
(136,85)
(136,86)
(137,22)
(137,5)
(138,56)
(138,130)
(139,78)
(139,130)
(140,71)
(140,164)
(141,164)
(141,71)
(142,36)
(142,83)
(143,156)
(143,131)
(144,87)
(144,103)
(145,61)
(145,145)
(146,44)
(146,76)
(147,50)
(147,56)
(148,50)
(148,56)
(149,92)
(149,36)
(150,142)
(150,159)
(151,125)
(151,100)



-- Insérer des évolutions
INSERT INTO Pokedex.Evolution (id_pokemon, pokemon_evolue_id) VALUES
	(1, 2),   -- Bulbizarre évolue en Herbizarre
	(2, 3),   -- Herbizarre évolue en Florizarre
	(3, NULL), -- Florizarre n'évolue pas
	(4, 5),   -- Salamèche évolue en Reptincel
	(5, 6),   -- Reptincel évolue en Dracaufeu
	(6, NULL), -- Dracaufeu n'évolue pas
	(7, 8),   -- Carapuce évolue en Carabaffe
	(8, 9),   -- Carabaffe évolue en Tortank
	(9, NULL), -- Tortank n'évolue pas
	(10, 11), -- Chenipan évolue en Chrysacier
	(11, 12), -- Chrysacier évolue en Papilusion
	(12, NULL), -- Papilusion n'évolue pas
	(13, 14), -- Aspicot évolue en Coconfort
	(14, 15), -- Coconfort évolue en Dardargnan
	(15, NULL), -- Dardargnan n'évolue pas
	(16, 17), -- Roucool évolue en Roucoups
	(17, 18), -- Roucoups évolue en Roucarnage
	(18, NULL), -- Roucarnage n'évolue pas
	(19, 20), -- Rattata évolue en Rattatac
	(20, NULL), -- Rattatac n'évolue pas
	(21, 22), -- Piafabec évolue en Rapasdepic
	(22, NULL), -- Rapasdepic n'évolue pas
	(23, 24), -- Abo évolue en Arbok
	(24, NULL), -- Arbok n'évolue pas
	(25, 26), -- Pikachu évolue en Raichu
	(26, NULL), -- Raichu n'évolue pas
	(27, 28), -- Sabelette évolue en Sablaireau
	(28, NULL), -- Sablaireau n'évolue pas
	(29, 30), -- Nidoran♀ évolue en Nidorina
	(30, 31), -- Nidorina évolue en Nidoqueen
	(31, NULL), -- Nidoqueen n'évolue pas
	(32, 33), -- Nidoran♂ évolue en Nidorino
	(33, 34), -- Nidorino évolue en Nidoking
	(34, NULL), -- Nidoking n'évolue pas
	(35, 36), -- Mélofée évolue en Mélodelfe
	(36, NULL), -- Mélodelfe n'évolue pas
	(37, 38), -- Goupix évolue en Feunard
	(38, NULL), -- Feunard n'évolue pas
	(39, 40), -- Rondoudou évolue en Grodoudou
	(40, NULL), -- Grodoudou n'évolue pas
	(41, 42), -- Nosferapti évolue en Nosferalto
	(42, NULL), -- Nosferalto n'évolue pas
	(43, 44), -- Mystherbe évolue en Ortide
	(44, 45), -- Ortide évolue en Rafflesia
	(45, NULL), -- Rafflesia n'évolue pas
	(46, 47), -- Paras évolue en Parasect
	(47, NULL), -- Parasect n'évolue pas
	(48, 49), -- Mimitoss évolue en Aéromite
	(49, NULL), -- Aéromite n'évolue pas
	(50, 51), -- Taupiqueur évolue en Triopikeur
	(51, NULL), -- Triopikeur n'évolue pas
	(52, 53), -- Miaouss évolue en Persian
	(53, NULL), -- Persian n'évolue pas
	(54, 55), -- Psykokwak évolue en Akwakwak
	(55, NULL), -- Akwakwak n'évolue pas
	(56, 57), -- Férosinge évolue en Colossinge
	(57, NULL), -- Colossinge n'évolue pas
	(58, 59), -- Caninos évolue en Arcanin
	(59, NULL), -- Arcanin n'évolue pas
	(60, 61), -- Ptitard évolue en Têtarte
	(61, 62), -- Têtarte évolue en Tartard
	(62, NULL), -- Tartard n'évolue pas
	(63, 64), -- Abra évolue en Kadabra
	(64, 65), -- Kadabra évolue en Alakazam
	(65, NULL), -- Alakazam n'évolue pas
	(66, 67), -- Machoc évolue en Machopeur
	(67, 68), -- Machopeur évolue en Mackogneur
	(68, NULL), -- Mackogneur n'évolue pas
	(69, 70), -- Chétiflor évolue en Boustiflor
	(70, 71), -- Boustiflor évolue en Empiflor
	(71, NULL), -- Empiflor n'évolue pas
	(72, 73), -- Tentacool évolue en Tentacruel
	(73, NULL), -- Tentacruel n'évolue pas
	(74, 75), -- Racaillou évolue en Gravalanch
	(75, 76), -- Gravalanch évolue en Grolem
	(76, NULL), -- Grolem n'évolue pas
	(77, 78), -- Ponyta évolue en Galopa
	(78, NULL), -- Galopa n'évolue pas
	(79, 80), -- Ramoloss évolue en Flagadoss
	(80, NULL), -- Flagadoss n'évolue pas
	(81, 82), -- Magnéti évolue en Magnéton
	(82, NULL), -- Magnéton n'évolue pas
	(83, NULL), -- Canarticho n'évolue pas
	(84, 85), -- Doduo évolue en Dodrio
	(85, NULL), -- Dodrio n'évolue pas
	(86, 87), -- Otaria évolue en Lamantine
	(87, NULL), -- Lamantine n'évolue pas
	(88, 89), -- Tadmorv évolue en Grotadmorv
	(89, NULL), -- Grotadmorv n'évolue pas
	(90, 91), -- Kokiyas évolue en Crustabri
	(91, NULL), -- Crustabri n'évolue pas
	(92, 93), -- Fantominus évolue en Spectrum
	(93, 94), -- Spectrum évolue en Ectoplasma
	(94, NULL), -- Ectoplasma n'évolue pas
	(95, NULL), -- Onix n'évolue pas
	(96, 97), -- Soporifik évolue en Hypnomade
	(97, NULL), -- Hypnomade n'évolue pas
	(98, 99), -- Krabby évolue en Krabboss
	(99, NULL), -- Krabboss n'évolue pas
	(100, 101), -- Voltorbe évolue en Électrode
	(101, NULL), -- Électrode n'évolue pas
	(102, 103), -- Nœunœuf évolue en Noadkoko
	(103, NULL), -- Noadkoko n'évolue pas
	(104, 105), -- Osselait évolue en Ossatueur
	(105, NULL), -- Ossatueur n'évolue pas
	(106, NULL), -- Kicklee n'évolue pas
	(107, NULL), -- Tygnon n'évolue pas
	(108, NULL), -- Excelangue n'évolue pas
	(109, 110), -- Smogo évolue en Smogogo
	(110, NULL), -- Smogogo n'évolue pas
	(111, 112), -- Rhinocorne évolue en Rhinoféros
	(112, NULL), -- Rhinoféros n'évolue pas
	(113, NULL), -- Leveinard n'évolue pas
	(114, NULL), -- Saquedeneu n'évolue pas
	(115, NULL), -- Kangourex n'évolue pas
	(116, 117), -- Hypotrempe évolue en Hypocéan
	(117, NULL), -- Hypocéan n'évolue pas
	(118, 119), -- Poissirène évolue en Poissoroy
	(119, NULL), -- Poissoroy n'évolue pas
	(120, 121), -- Stari évolue en Staross
	(121, NULL), -- Staross n'évolue pas
	(122, NULL), -- M. Mime n'évolue pas
	(123, NULL), -- Insécateur n'évolue pas
	(124, NULL), -- Lippoutou n'évolue pas
	(125, NULL), -- Élektek n'évolue pas
	(126, NULL), -- Magmar n'évolue pas
	(127, NULL), -- Scarabrute n'évolue pas
	(128, NULL), -- Tauros n'évolue pas
	(129, 130), -- Magicarpe évolue en Léviator
	(130, NULL), -- Léviator n'évolue pas
	(131, NULL), -- Lokhlass n'évolue pas
	(132, NULL), -- Métamorph n'évolue pas
	(133, 134), -- Évoli évolue en Aquali
	(133, 135), -- Évoli évolue en Voltali
	(133, 136), -- Évoli évolue en Pyroli
	(134, NULL), -- Aquali n'évolue pas
	(135, NULL), -- Voltali n'évolue pas
	(136, NULL), -- Pyroli n'évolue pas
	(137, NULL), -- Porygon n'évolue pas
	(138, 139), -- Amonita évolue en Amonistar
	(139, NULL), -- Amonistar n'évolue pas
	(140, 141), -- Kabuto évolue en Kabutops
	(141, NULL), -- Kabutops n'évolue pas
	(142, NULL), -- Ptéra n'évolue pas
	(143, NULL), -- Ronflex n'évolue pas
	(144, NULL), -- Artikodin n'évolue pas
	(145, NULL), -- Électhor n'évolue pas
	(146, NULL), -- Sulfura n'évolue pas
	(147, 148), -- Minidraco évolue en Draco
	(148, 149), -- Draco évolue en Dracolosse
	(149, NULL), -- Dracolosse n'évolue pas
	(150, NULL), -- Mewtwo n'évolue pas
	(151, NULL); -- Mew n'évolue pas



