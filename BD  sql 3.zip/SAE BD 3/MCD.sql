-- Nom du schéma : Pokedex
Drop Schema IF Exists Pokedex cascade;
CREATE SCHEMA Pokedex;

-- Table : Pokemon
CREATE TABLE Pokedex.Pokemon (
    id_pokemon INT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    pokedex_number INT NOT NULL,
    attaque_base INT NOT NULL,
    attaquespe_base INT NOT NULL,
    defense_base INT NOT NULL,
    defensespe_base INT NOT NULL,
    vitesse_base INT NOT NULL,
    pv_base INT NOT NULL
);

-- Table : Type
CREATE TABLE Pokedex.Type (
    id_type INT PRIMARY KEY,
    nom_type VARCHAR(50) NOT NULL
);

-- Table d'association : A_pour_Type
CREATE TABLE Pokedex.A_pour_Type (
    id_pokemon INT NOT NULL,
    id_type INT NOT NULL,
    PRIMARY KEY (id_pokemon, id_type),
    FOREIGN KEY (id_pokemon) REFERENCES Pokedex.Pokemon(id_pokemon),
    FOREIGN KEY (id_type) REFERENCES Pokedex.Type(id_type)
);

-- Table : Attaque
CREATE TABLE Pokedex.Attaque (
    id_attaque INT PRIMARY KEY,
    nom_attaque VARCHAR(50) NOT NULL,
    type_attaque VARCHAR(50) NOT NULL
);

-- Table d'association : Peut_apprendre
CREATE TABLE Pokedex.Peut_apprendre (
    id_pokemon INT NOT NULL,
    id_attaque INT NOT NULL,
    PRIMARY KEY (id_pokemon, id_attaque),
    FOREIGN KEY (id_pokemon) REFERENCES Pokedex.Pokemon(id_pokemon),
    FOREIGN KEY (id_attaque) REFERENCES Pokedex.Attaque(id_attaque)
);

-- Table : Evolution
CREATE TABLE Pokedex.Evolution (
    id_evolution INT PRIMARY KEY,
    id_pokemon INT NOT NULL,
    pokemon_evolue_id INT NOT NULL,
    FOREIGN KEY (id_pokemon) REFERENCES Pokedex.Pokemon(id_pokemon),
    FOREIGN KEY (pokemon_evolue_id) REFERENCES Pokedex.Pokemon(id_pokemon)
);

